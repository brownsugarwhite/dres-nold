/* <praxis-karte> — interaktive OpenStreetMap-Karte (Leaflet) mit animiertem Marker.
   Erwartet, dass Leaflet (window.L) über <script> geladen ist. Attribute: lat, lon, zoom. */
(function () {
  const CSS = `
praxis-karte{display:block;position:relative;overflow:hidden;background:#fff;isolation:isolate;z-index:0}
praxis-karte .pk-map{position:absolute;inset:0;background:#f4f1f3;cursor:grab}
praxis-karte .pk-map:active{cursor:grabbing}
praxis-karte .leaflet-tile-pane{filter:grayscale(1) brightness(1.1) contrast(.82);opacity:.9}
praxis-karte .pk-overlay{position:absolute;left:0;top:0;z-index:500;pointer-events:none;will-change:transform}
praxis-karte .pk-tint{position:absolute;inset:0;pointer-events:none;background:#6c1a51;opacity:.045;mix-blend-mode:multiply}
praxis-karte .pk-fade{position:absolute;inset:0;pointer-events:none;background:linear-gradient(to bottom,#ffffff 0,rgb(255 255 255 / .97) 12%,rgb(255 255 255 / .86) 30%,rgb(255 255 255 / .5) 55%,rgb(255 255 255 / .12) 80%,rgb(255 255 255 / 0) 100%)}
@media (max-width:1040px){praxis-karte .pk-fade{background:linear-gradient(to bottom,#ffffff 0,rgb(255 255 255 / .97) 16%,rgb(255 255 255 / .85) 36%,rgb(255 255 255 / .4) 56%,rgb(255 255 255 / 0) 74%)}}
praxis-karte .leaflet-control-attribution{font:400 11px/1.4 'Source Sans 3',system-ui,sans-serif;color:#766c74;background:rgb(255 255 255 / .8);padding:3px 8px;border-radius:6px 0 0 0}
praxis-karte .leaflet-control-attribution a{color:#6c1a51}
praxis-karte .leaflet-control-zoom{border:0!important;box-shadow:0 12px 30px -18px rgba(30,8,22,.5)!important;border-radius:999px!important;overflow:hidden;margin:18px!important}
praxis-karte .leaflet-control-zoom a{width:40px!important;height:40px!important;line-height:40px!important;color:#6c1a51!important;background:rgb(255 255 255 / .92)!important;border:0!important;font:300 22px/40px 'Source Sans 3',system-ui,sans-serif!important;transition:background .3s}
praxis-karte .leaflet-control-zoom a:hover{background:#fff!important}
praxis-karte .leaflet-control-zoom a:first-child{border-bottom:1px solid #e4e0e2!important}
praxis-karte .pk-pin{position:relative;width:52px;height:72px;transform-origin:50% 100%}
praxis-karte .pk-pin svg{position:absolute;left:0;top:0;width:52px;height:72px;display:block;filter:drop-shadow(0 10px 14px rgba(30,8,22,.35))}
praxis-karte .pk-pin .pk-halo{position:absolute;left:50%;bottom:0;width:26px;height:26px;margin-left:-13px;margin-bottom:-13px;border-radius:50%;border:1.5px solid #6c1a51;opacity:0;transform:scale(.3)}
praxis-karte .pk-pin.da svg{animation:pk-drop .9s cubic-bezier(.22,.61,.24,1) both}
praxis-karte .pk-pin.da .pk-halo{animation:pk-halo 2.6s cubic-bezier(.22,.61,.24,1) .9s infinite}
praxis-karte .pk-pin.da .pk-halo.b{animation-delay:2.2s}
praxis-karte .pk-pin:not(.da) svg{opacity:0;transform:translateY(-60px)}
@keyframes pk-drop{0%{opacity:0;transform:translateY(-70px) scale(.9)}60%{opacity:1;transform:translateY(4px) scale(1.02)}80%{transform:translateY(-3px) scale(1)}100%{opacity:1;transform:translateY(0) scale(1)}}
@keyframes pk-halo{0%{opacity:.7;transform:scale(.3)}100%{opacity:0;transform:scale(4.5)}}
praxis-karte .leaflet-marker-icon{background:none;border:0}
praxis-karte .leaflet-marker-pane{z-index:650}
@media (prefers-reduced-motion:reduce){praxis-karte .pk-pin.da svg{animation:none}praxis-karte .pk-pin.da .pk-halo{animation:none;opacity:.35;transform:scale(2.2)}}
`;
  if (!document.getElementById('pk-css')) {
    const s = document.createElement('style'); s.id = 'pk-css'; s.textContent = CSS; document.head.appendChild(s);
  }

  const PIN = `<svg viewBox="0 0 52 72" aria-hidden="true">
<path d="M26 1C12.2 1 1 12 1 25.6 1 44.5 26 71 26 71S51 44.5 51 25.6C51 12 39.8 1 26 1Z" fill="#6c1a51" stroke="#ffffff" stroke-width="2"/>
<circle cx="26" cy="25.5" r="9.5" fill="#ffffff"/>
<circle cx="26" cy="25.5" r="4.2" fill="#6c1a51"/>
</svg>`;

  class PraxisKarte extends HTMLElement {
    connectedCallback() {
      if (this._init) return; this._init = true;
      this.style.height = this.getAttribute('hoehe') || '520px'; this.style.width = '100%';
      if (this.parentElement && this.parentElement.matches('[data-x-import], x-import, div')) { this.parentElement.style.height = '100%'; }
      this.innerHTML = '<div class="pk-map"></div>';
      const warten = () => (window.L ? this.starten() : setTimeout(warten, 60));
      warten();
    }
    starten() {
      const L = window.L;
      const lat = parseFloat(this.getAttribute('lat') || '48.91052');
      const lon = parseFloat(this.getAttribute('lon') || '8.2516');
      const zoomZiel = parseFloat(this.getAttribute('zoom') || '16');
      const el = this.querySelector('.pk-map');
      const ruhig = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      const map = L.map(el, {
        center: [lat, lon], zoom: ruhig ? zoomZiel : zoomZiel - 3,
        scrollWheelZoom: false, zoomControl: false, attributionControl: true, zoomSnap: .25
      });
      map.attributionControl.setPrefix(false);
      // Tönung und Weißverlauf als eigene Leaflet-Ebene zwischen Kacheln (200) und Markern (600).
      // Die Map-Pane wird beim Verschieben transformiert — der Verlauf wird gegengerechnet, damit er fest im Bild steht.
      const ebene = map.createPane('pk-overlay'); ebene.className += ' pk-overlay';
      ebene.innerHTML = '<div class="pk-tint"></div><div class="pk-fade"></div>';
      const fest = () => {
        const off = L.DomUtil.getPosition(map.getPane('mapPane')) || L.point(0, 0);
        ebene.style.transform = 'translate(' + (-off.x) + 'px,' + (-off.y) + 'px)';
        ebene.style.width = el.clientWidth + 'px'; ebene.style.height = el.clientHeight + 'px';
      };
      map.on('move zoom zoomend viewreset resize load', fest); fest();
      const roFest = new ResizeObserver(fest); roFest.observe(el);
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap-Mitwirkende', maxZoom: 19
      }).addTo(map);
      L.control.zoom({ position: 'bottomright' }).addTo(map);

      const icon = L.divIcon({
        className: '', iconSize: [52, 72], iconAnchor: [26, 71],
        html: '<div class="pk-pin">' + PIN + '<span class="pk-halo"></span><span class="pk-halo b"></span></div>'
      });
      const marker = L.marker([lat, lon], { icon, keyboard: false, interactive: false }).addTo(map);
      const pin = () => marker.getElement() && marker.getElement().querySelector('.pk-pin');

      // Pin-Position aus dem echten Layout messen:
      // breit → in der Lücke zwischen Textspalte und Formular; gestapelt → oben rechts über dem Formular.
      const freiePosition = () => {
        const sek = this.closest('section') || this.parentElement;
        const r = el.getBoundingClientRect();
        const boxen = [...sek.querySelectorAll('[data-stapel-breit] > *')].map((k) => k.getBoundingClientRect()).filter((b) => b.height > 0);
        const schmal = el.clientWidth <= 1040;
        if (!schmal && boxen.length >= 2) {
          const links = boxen[0], rechts = boxen[1];
          const x = (links.right + rechts.left) / 2 - r.left;
          const y = Math.max(links.bottom, rechts.top + rechts.height * 0.55) - r.top;
          return { x, y: Math.min(y, r.height - 60) };
        }
        const form = boxen[boxen.length - 1];
        if (form) return { x: form.right - r.left - 36, y: form.top - r.top - 26 };
        return { x: r.width / 2, y: r.height / 2 };
      };
      const ziel = (zoom) => {
        const pos = freiePosition();
        const dx = pos.x - el.clientWidth / 2;
        const dy = pos.y - el.clientHeight / 2;
        const p = map.project([lat, lon], zoom).subtract([dx, dy]);
        return map.unproject(p, zoom);
      };
      map.setView(ziel(map.getZoom()), map.getZoom(), { animate: false });

      let gestartet = false;
      const los = () => {
        if (gestartet) return; gestartet = true;
        if (ruhig) { map.setView(ziel(zoomZiel), zoomZiel, { animate: false }); const p = pin(); if (p) p.classList.add('da'); return; }
        setTimeout(() => {
          map.flyTo(ziel(zoomZiel), zoomZiel, { duration: 2.2, easeLinearity: .2 });
          map.once('moveend', () => { const p = pin(); if (p) p.classList.add('da'); });
        }, 250);
      };
      const io = new IntersectionObserver((e) => { if (e.some((x) => x.isIntersecting)) { los(); io.disconnect(); } }, { threshold: .3 });
      io.observe(this);

      this._ro = new ResizeObserver(() => { map.invalidateSize(); if (gestartet) map.setView(ziel(map.getZoom()), map.getZoom(), { animate: false }); });
      this._ro.observe(this);
      this._map = map;
    }
    disconnectedCallback() { if (this._ro) this._ro.disconnect(); if (this._map) this._map.remove(); this._init = false; }
  }
  if (!customElements.get('praxis-karte')) customElements.define('praxis-karte', PraxisKarte);
})();
